<?php
session_start();

// Only proceed if form was submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $productId = $_POST['product_id'] ?? null;
    $productName = $_POST['product_name'] ?? '';
    $price = $_POST['price'] ?? 0;

    // Initialize cart if not set
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Add to session cart
    $_SESSION['cart'][] = [
        'id' => $productId,
        'name' => $productName,
        'price' => $price
    ];

    echo "<h3>Product '$productName' added to cart successfully!</h3>";
    echo "<a href='products.php'>← Back to products</a>";
} else {
    echo "<h3>No product submitted.</h3>";
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Register - E-Commerce</title>
</head>
<body>
    <h2>Register</h2>
    <?php if ($message): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label>Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Register</button>
    </form>
</body>
</html>
