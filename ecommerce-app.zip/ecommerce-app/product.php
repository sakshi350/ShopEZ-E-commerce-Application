<?php
session_start();
include 'includes/db.php';

// Fetch products from DB
$sql = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products - E-Commerce</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Optional -->
    <style>
        .product {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px;
            width: 200px;
            float: left;
        }
        .product img {
            width: 100%;
            height: 150px;
        }
    </style>
</head>
<body>
    <h2>Welcome <?php echo isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'Guest'; ?>!</h2>

    <h3>Available Products</h3>
    <div>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="product">
             <img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                <h4><?php echo $row['name']; ?></h4>
                <p>₹<?php echo $row['price']; ?></p>
                <form method="POST" action="cart.php">
                    <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                    <input type="hidden" name="product_name" value="<?php echo $row['name']; ?>">
                    <input type="hidden" name="price" value="<?php echo $row['price']; ?>">
                    <input type="submit" value="Add to Cart">
                </form>
            </div>
        <?php } ?>
    </div>
</body>
</html>
