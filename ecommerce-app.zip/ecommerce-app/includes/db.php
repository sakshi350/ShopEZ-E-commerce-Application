<?php
$servername = "localhost";    // Usually 'localhost'
$username = "root";           // Default username for XAMPP/WAMP
$password = "";               // Default is empty for XAMPP/WAMP
$database = "ecommerce_db";      // Change this to your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
